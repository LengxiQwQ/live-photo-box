<div align="center">

# Apple Live Photo 实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析 Apple Live Photo 的双文件配对、QuickTime 元数据、MOV 轨道结构、封面帧位置与容器要求。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

Apple Live Photo 采用双文件结构：静态图片和动态视频彼此独立，通过共享的 `ContentIdentifier` UUID 配对。

## 文件结构

iPhone 拍摄的实况照片由两个独立文件组成：

```
IMG_1234.HEIC  — 静态照片（HEIF 容器，含封面帧图像；JPG 同样可行）
IMG_1234.MOV   — 动态视频（QuickTime 容器，约 3 秒，含音频轨）

```

## 配对机制

两个文件存储相同的 `ContentIdentifier` UUID。此 UUID 由 iPhone 在拍摄时生成，写入 QuickTime 顶级元数据：

```
IMG_1234.HEIC → ContentIdentifier = "D4E5F6A7-89AB-4CDE-..."
IMG_1234.MOV  → ContentIdentifier = "D4E5F6A7-89AB-4CDE-..."  （完全一致）

```
配对优先级：ContentIdentifier UUID > 文件名 > 拍摄日期+GPS 兜底。

## HEIC 元数据

| 元数据字段 | 位置 | 说明 |
|-----------|------|------|
| `ContentIdentifier` | MakerNotes (QuickTime) | **配对 UUID**，与 MOV 中的一致 |
| `QuickTime:Rotation` | QuickTime 元数据 | 旋转方向（如 `Rotate 90 CW`） |
| `EXIF:Orientation` | EXIF IFD | EXIF 方向标签。可能与 `Rotation` 不一致 |

> `Orientation` 与 `Rotation` 用于修复页面的方向校正，不影响实况照片识别。

## MOV 元数据

| 元数据字段 | 位置 | 说明 |
|-----------|------|------|
| `ContentIdentifier` | QuickTime 顶级（moov/meta/ilst） | **配对 UUID**，与照片端的 MakerNote 一致 |
| `ContentDescribes` | meBx 轨（Track 3） | **内容描述元数据轨**，其 stsd keys 里是 `com.apple.quicktime.live-photo-info` |
| `LivePhotoAuto` | QuickTime 顶级 | **实况照片自动标记**，值为 `1` |
| `LivePhotoVitalityScore` | QuickTime 顶级 | 活力评分，0~1 之间 |
| `LivePhotoVitalityScoringVersion` | QuickTime 顶级 | 活力评分算法版本，当前为 `4` |
| `PosterTime` | QuickTime Movie 级别 | 始终为 `0 s`，**不反映真实封面帧位置** |
| `StillImageTime` | 封面轨（Track 4）elst | 空编辑段 `media_time=-1`，其 `TrackDuration` 才是封面帧在视频中的实际秒数 |
| `QuickTime:Matrix` | Movie 级别 | 3×3 仿射变换矩阵（通常 identity） |
| `QuickTime:Matrix` | Track 1 级别 | 视频轨的 3×3 旋转矩阵 |
| `MediaDuration` | Track 1 | 视频时长（秒），通常 2.7~3.0 秒 |

> `LivePhotoAuto`、`LivePhotoVitalityScore`、`LivePhotoVitalityScoringVersion` 为活力评分相关字段，非识别、配对、编辑的前提。

## MOV 轨道结构

iOS 可识别的最小结构（Next Track ID = 5，即 4 个轨道）：

| Track ID | 类型 | Handler | 说明 |
|:---:|------|------|------|
| 1 | Video Track | Core Media Video | 视频轨，HEVC (hvc1) 编码，含旋转矩阵 |
| 2 | Audio Track | Core Media Audio | 音频轨 |
| 3 | NRT Metadata | Core Media Metadata | 元数据轨，`ContentDescribes` 指向 Track 1 |
| 4 | NRT Metadata | Core Media Metadata | 封面帧轨（mebx），携带 StillImageTime / 封面变换 |

每个媒体轨（Video/Audio/两个 Metadata）的 `minf` 内还各带一个 **Alias Data Handler**（`dhlr`/`alis`/`appl`，名称为 "Core Media Data Handler"）。

> 实拍文件有 11~12 个轨道，含多个 Auxiliary Picture 轨（sky map、person map 等）；4 轨为最小结构，其余轨道与识别、播放、编辑无关。

## 封面帧机制

与 Google/OPPO 用微秒时间戳指向视频中某一帧不同，Apple 的封面帧位置藏在 MOV 文件的 **Timed Metadata 轨道**（mebx 类型）中。具体机制：

1. MOV 的 Movie 级别 `PosterTime` **始终为 0**，不反映实际封面位置
2. 封面位置由**封面轨（Track 4）的 elst** 表达：第一段是空编辑（`media_time=-1`），其时长 = 封面在视频中的时间点（以 MovieTimeScale 44100 为单位）；第二段是 74 tick 的封面媒体
3. 封面轨的 meBx 载荷是 89 字节固定数据
4. **该轨的 `TrackDuration` 即封面帧在视频时间轴上的位置**（秒）

更换封面帧时，需要更新封面轨 elst 的空编辑时长（封面时间点），封面载荷本身保持不变。

## Apple 兼容实况照片的最低要求

iOS 识别一组文件为实况照片需要：

**照片端**（HEIC **或** JPG 均可）：

- Apple MakerNote 中写入 `ContentIdentifier` UUID（仅此一项即可；70 字节最小 MakerNote）
  - MakerNote 必须位于 **ExifIFD**（tag `0x927C`），且该 IFD 中**只能有这一条** `0x927C`。
    写到 IFD0 或同一 ExifIFD 里存在重复 `0x927C` 时，iOS 不会将其识别/导入为实况照片。

> 华为/荣耀原生照片转 Apple 时，其图片 ExifIFD 常自带 1~4 条 `0x927C`
> （如华为 `##**N4021`、荣耀 `AF_C` 等原生 MakerNote）。转换前必须先删除全部旧 `0x927C`，
> 再写入唯一一条 Apple MakerNote；华为 `VLDMAGIC`、荣耀 `BKQ_PRO` 等相机私有数据可原样保留，
> 不影响 iOS 导入。

**视频端**（MOV）：

- `ContentIdentifier` UUID（与照片端一致）
- `Software = "17.0.2"`、`CreationDate`
- 4 轨最小结构：Video + Audio + ContentDescribes(meBx) + 封面(meBx)

## QuickTime 容器结构

1. 顶部容器顺序为 `ftyp + moov + wide + mdat`，`moov` 前移，单 `mdat`。
   - `ftyp`：major brand `qt  `、minor 0、compatible `qt  `，共 20 字节（缺 compatible 会导致识别异常）。
   - `wide`：8 字节占位，紧跟 moov。
   - `mdat`：视频数据 → 音频数据 → ContentDescribes 数据 → 封面数据，顺序和 stco 一致。

2. 轨道结构为 4 轨：Video(hvc1) + Audio(mp4a) + ContentDescribes(meBx) + 封面(meBx)。
   - 视频轨 `tapt` 必须含 `clef/prof/enof` 三个 20 字节 FullBox（size + type + version/flags + width/height）。
   - 每个媒体轨的 `minf` 内带 Alias Data Handler：`hdlr` 的 componentType=`dhlr`、subtype=`alis`、manufacturer=`appl`。
   - `vmhd` 的 flags=1、graphicsMode=0x40(ditherCopy)、opColor=0x8000×3；Metadata 轨用 `gmhd/gmin`。
   - `hdlr` 的布局是 `version/flags + componentType + componentSubtype + manufacturer + componentFlags + componentFlagsMask + Pascal 名`。

3. `meta` 位于 moov 直属（不是 `udta/meta`），无 version/flags。
   - `hdlr`：componentType=0、subtype=`mdta`、manufacturer=0、空名。
   - `keys`：3 个键，按序为 `com.apple.quicktime.content.identifier / .software / .creationdate`。
   - `ilst`：3 个 item，index 1~3 与 keys 一一对应，data type=1(UTF-8)。

4. 配对只靠 ContentIdentifier：照片端 MakerNote 与 MOV 端 `meta/ilst` 写同一 UUID。
   - 照片端 Apple MakerNote 为 70 字节：`"Apple iOS\0\0\1" + "MM" + 1 条目(tag 0x0011 ContentIdentifier)`。
   - JPG 和 HEIC 均可行。

5. 封面帧在封面轨的 elst 里：封面轨 `elst = [empty_edit(cover_time), cover_media(74 ticks)]`，cover_time 用 MovieTimeScale(44100) 表示；封面 meBx 载荷为 89 字节固定数据。

6. ContentDescribes 轨的 meBx 载荷为 144 字节，每段视频重复 `round((时长-0.05)*60)` 次；其 stsd 里的 keys 载荷为 515 字节私有结构（含 `dims=1920x1440`）。

7. 视频必须全 I 帧（每一帧都是同步帧）。
   - 常规 GOP 下（例如 `-g 15`）3 秒视频只有 7 个关键帧，iOS 编辑实况照片拖动时间轴只显示 7 帧，且只能在这 7 帧里选封面。
   - 全 I 帧（`-g 1`）下 90 帧全部是同步帧，可逐帧拖动、任选封面。
   - 全 I 帧的码率/体积约为常规 GOP 的 3~4 倍。

8. 视频编码 hvc1 和 avc1 均可；音频 AAC 任意声道数/采样率（44.1k/48k/22.05k）。时间轴/采样表保留源时序，不归一化成固定 timescale。

## 旋转矩阵

Apple 使用 3×3 仿射变换矩阵表示视频方向，而非单一角度值：

| 矩阵 | 含义 | 等效旋转 |
|------|------|:---:|
| `[1 0 0 · 0 1 0 · 0 0 1]` | 正常 | 0° |
| `[0 1 0 · -1 0 0 · 0 0 1]` | 正手持拍摄 | 顺时针 90° |
| `[-1 0 0 · 0 -1 0 · 0 0 1]` | 倒置拍摄 | 180° |
| `[0 -1 0 · 1 0 0 · 0 0 1]` | 反手持拍摄 | 顺时针 270° |
| `[1 0 0 · 0 -1 0 · 0 0 1]` | 前置摄像头翻转 (A) | 0°（上下镜像） |
| `[-1 0 0 · 0 1 0 · 0 0 1]` | 前置摄像头翻转 (B) | 180°（上下镜像） |

数值可能以普通整数（-1, 0, 1）或 16.16 定点数（65536=1.0, 16384=0.25）表示。

## 常见问题

| 问题 | 原因 | 表现 |
|------|------|------|
| 缩略图横向拉伸 | iOS 17.3 之前 Apple 嵌入低分辨率缩略图但保留方向标签 | Windows 将其当作横向图片，导致宽高比错误 |
| 前置摄像头视频旋转异常 | 前置摄像头纵向像素横向存储，方向由旋转矩阵指示 | Windows 不读取 QuickTime 旋转矩阵，视频方向错误 |
| HEIC 方向不一致 | EXIF `Orientation` 与 `QuickTime:Rotation` 标注不同 | 不同软件读取不同标签，显示方向各异 |
| ContentIdentifier 丢失 | 跨平台传输时部分工具不保留 QuickTime 元数据 | 照片与视频配对关系断裂 |

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
