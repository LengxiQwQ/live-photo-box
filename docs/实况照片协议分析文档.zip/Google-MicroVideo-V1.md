<div align="center">

# Google MicroVideo V1 实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析 Google MicroVideo V1 的文件结构、XMP 元数据、视频定位与封面帧机制。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

Google 最早的实况照片格式，已弃用，但旧设备（旧 Pixel、MIUI 时代的小米）仍大量使用。

> **相关协议**：现代版本见 [Google MotionPhoto V2](./Google-MotionPhoto-V2.md)。

## 文件结构

JPEG 图片位于文件前部，MP4 视频直接拼接在 JPEG 末尾：

```text
┌──────────────────────┐
│ JPEG 图片（EXIF + XMP）│
├──────────────────────┤
│ MP4 视频              │
└──────────────────────┘
```

视频通常使用 `ftyp=mp42/isom`。

## XMP 元数据

使用 `GCamera` 命名空间，自闭合 `rdf:Description` 标签，共 4 个数据属性：

```xml
<rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    GCamera:MicroVideo="1"
    GCamera:MicroVideoVersion="1"
    GCamera:MicroVideoOffset="4424761"
    GCamera:MicroVideoPresentationTimestampUs="459334"/>

```

### 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `GCamera:MicroVideo` | 整数 | 实况照片标识。值为 `1` |
| `GCamera:MicroVideoVersion` | 整数 | 协议版本，固定为 `1` |
| `GCamera:MicroVideoOffset` | 整数 | 视频字节数。从文件末尾向前推算：图片长度 = 文件总大小 − 此值 |
| `GCamera:MicroVideoPresentationTimestampUs` | 整数 | 封面帧在视频中的微秒时间戳。`0` = 视频开头 |

## 视频定位与提取

1. 读取 `MicroVideoOffset` 值
2. 图片部分 = 文件前 `totalSize − MicroVideoOffset` 字节
3. 视频部分 = 文件后 `MicroVideoOffset` 字节

## 封面帧机制

`GCamera:MicroVideoPresentationTimestampUs` 直接给出封面帧在视频中的微秒位置。例如值为 `459334` 即视频第 0.46 秒处为封面。值为 `0` 表示封面在视频开头。

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
