<div align="center">

# Google MotionPhoto V2 实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析 Google MotionPhoto V2 的容器目录、XMP 字段、视频定位与封面帧规则。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

Google 的现代实况照片标准。使用 `Container:Directory` 结构化 XMP 描述文件内容。目前兼容性最广，Windows 11 文件资源管理器可原生预览。

- 规范名称：**Motion Photo format 1.0**
- 官方文档：<https://developer.android.com/media/platform/motion-photo-format>

使用者：Google Pixel、三星 Galaxy、小米（HyperOS）、摩托罗拉等。

> **相关协议**：旧版协议及字段差异见 [Google MicroVideo V1](./Google-MicroVideo-V1.md)。

## 文件结构

JPEG 图片数据在前，视频数据（MP4 或 MOV）直接追加在 JPEG EOI（`FF D9`）之后，无分隔符。

规范要求：Container:Directory 中各 Item **必须**按其在文件中出现的实际顺序排列，且紧密排列（tightly packed）。`MotionPhoto` Item **必须**位于文件末尾，其后**不允许**有任何其他字节。

## XMP 元数据

使用 `GCamera`、`Container`、`Item` 三个命名空间。注意：官方规范中 Camera 命名空间的**默认前缀**为 `Camera`，但各厂商实现普遍使用 `GCamera`——XMP 以 URI 为准，前缀可任意，二者等价。

```xml
<rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="1230275">
  <Container:Directory>
    <rdf:Seq>
      <rdf:li rdf:parseType="Resource">
        <Container:Item Item:Mime="image/jpeg"
                        Item:Semantic="Primary"
                        Item:Length="0"
                        Item:Padding="0"/>
      </rdf:li>
      <rdf:li rdf:parseType="Resource">
        <Container:Item Item:Mime="video/mp4"
                        Item:Semantic="MotionPhoto"
                        Item:Length="4424761"
                        Item:Padding="0"/>
      </rdf:li>
    </rdf:Seq>
  </Container:Directory>
</rdf:Description>

```
> MicroVideo V1 的四个字段（`MicroVideo`、`MicroVideoVersion`、`MicroVideoOffset`、`MicroVideoPresentationTimestampUs`）在本规范中**已删除**，解析时**必须忽略**。视频定位应使用 `Container:Directory` 中的 `Item:Length`，而非 V1 的 `MicroVideoOffset`。

### 字段说明

**Camera 元数据**（命名空间 `http://ns.google.com/photos/1.0/camera/`）：

| 字段 | 类型 | 说明 |
|------|------|------|
| `MotionPhoto` | `Integer` | `0` = 不是 Motion Photo；`1` = 是 Motion Photo。**其他值均视为未定义，等效于 `0`**。由于多数图片编辑器会保留 XMP，即使视频已被移除，该字段仍可能残留值为 `1`。因此该字段**不是决定性证据**——阅读器必须实际确认视频是否存在。 |
| `MotionPhotoVersion` | `Integer` | 协议版本。本规范定义为 `1`。 |
| `MotionPhotoPresentationTimestampUs` | `Long` | 封面帧在视频中的微秒时间戳。可为 `-1` 表示未设置。 |

**Container 元数据**（命名空间 `http://ns.google.com/photos/1.0/container/`）：

`Container:Directory` 是一个有序的 `rdf:Seq` 结构。**有且仅有一个** `Primary` Item，且必须排在第一位。

**Item 元数据**（命名空间 `http://ns.google.com/photos/1.0/container/item/`）：

| 属性 | 类型 | 说明 |
|------|------|------|
| `Mime` | `String` | **必填**。MIME 类型：`image/jpeg`、`image/heic`、`image/avif`、`video/mp4`、`video/quicktime` |
| `Semantic` | `String` | **必填**。`Primary`=主图片（有且仅有一个），`MotionPhoto`=实况视频（有且仅有一个），`GainMap`=Ultra HDR 增益图（可选） |
| `Length` | `Integer` | 次级 Item **必填**。资源字节长度。Primary Item 应为 `0`（图片长度由 MIME 类型解析确定）。视频的 `Length` 使阅读器可直接从文件末尾倒退 `<Length>` 字节定位视频起点。 |
| `Padding` | `Integer` | 仅 Primary Item 可有此属性。JPEG 格式下可选。表示主图片编码结束到下一媒体项之间的填充字节数。 |

> 实践观察：小米 14 Pro（HyperOS）的原厂样本中，Primary Item 缺少 `Item:Length` 与 `Item:Padding` 属性。Google 规范允许解析器通过 JPEG 自身确定主图片长度，因此实现时应对此情况做容错处理。

## 视频定位

视频由 `Container:Directory` 中 `Semantic="MotionPhoto"` 的 Item 描述，`Item:Length` 为视频资源字节长度。读取时从文件末尾向前推 `Item:Length` 字节即可定位视频起点。

## 封面帧机制

`MotionPhotoPresentationTimestampUs` 指定封面帧在视频中的微秒位置。例如 `1230275` → 视频第 1.230275 秒。

**该字段缺失时的默认行为**（官方规范明确定义）：阅读器应使用视频时长**除以 2**，选择最接近中点的时间戳前一帧作为封面——**不是**"自行选择"。

## V2 相比 V1 的改进

| | MicroVideo V1 | MotionPhoto V2 |
|------|:---:|:---:|
| 资源描述 | 单一 `MicroVideoOffset` 字段 | `Container:Directory` 结构化目录 |
| MIME 类型 | 隐式 | 显式声明（`image/jpeg`、`video/mp4`、`video/quicktime` 等） |
| 可扩展性 | 不可扩展 | `rdf:Seq` 可添加更多资源项（如 Ultra HDR GainMap） |
| 填充支持 | 无 | `Item:Padding` 支持 |
| V1 兼容字段 | — | 规范要求忽略 V1 的四个字段 |
| 当前状态 | 已弃用 | 现行标准 |

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
