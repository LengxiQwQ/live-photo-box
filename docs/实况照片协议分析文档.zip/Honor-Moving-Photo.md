<div align="center">

# 荣耀 Moving Photo 实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析荣耀 Moving Photo 与华为共用的 LIVE_ 尾标机制，以及荣耀特有的逐帧防抖矩阵扩展。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

荣耀 Magic 系列动态照片采用与华为 Moving Photo 相同的核心协议：JPEG 中嵌入 MP4，并在文件尾部使用 `LIVE_` 标记识别实况照片。荣耀的主要差异是尾部前增加 `uuidextend_type_matrix` 逐帧防抖矩阵数据。

> **相关协议**：核心 `LIVE_`、尾部字段与 MP4 封面时间戳机制参考 [Huawei Moving Photo](./Huawei-Moving-Photo.md)，本文重点记录荣耀差异。

## 文件结构

```text
┌────────────────────────────┐
│ JPEG 主图片                 │
├────────────────────────────┤
│ MP4 视频                    │
├────────────────────────────┤
│ uuidextend_type_matrix JSON │  ← 荣耀私有扩展
├────────────────────────────┤
│ v2_fXX ... LIVE_NNNNNNN     │  ← 核心尾部
└────────────────────────────┘
```

荣耀真机尾部使用 `v2_fXX`，华为对应位置使用 `v6_fXX`；`PPP:QQQQ` 与 `LIVE_NNNNNNN` 的含义一致。

## 实况照片识别与视频定位

`LIVE_` 是核心判定标记。`LIVE_NNNNNNN` 中的数值为嵌入 MP4 字节数 + 20。

JPEG 读取到第一个 `FF D9` 可得到静态图片；视频从 JPEG EOI 之后的 MP4 `ftyp` 开始，结束于荣耀私有扩展和尾部之前。

## 封面帧机制

荣耀沿用华为 Moving Photo 的双机制：新版相册读取 MP4 udta 中的 `com.openharmony.covertime` 毫秒时间戳；旧版兼容使用尾部 `v2_fXX` 保存 0-based 帧序号。

更换封面时需要替换静态图片，并同步更新 `com.openharmony.covertime`、`v2_fXX` 与 `LIVE_`。`PPP:QQQQ` 作为历史记录保持原值。

## 荣耀私有防抖扩展

荣耀在标准尾部（`v2_fXX`、`PPP:QQQQ`、`LIVE_NNNNNNN`）前追加一段可变长的逐帧防抖矩阵 JSON：

```
uuidextend_type_matrix[{"frameNum":1,"matrixInfo":"{...}"}, ...]
v2_f43              499:1000            LIVE_7054584
└── 荣耀扩展（非实况）──┘└── 标准华为尾部 ──┘

```

JSON 中每个元素对应一个视频帧，记录该帧的 EIS（电子防抖）和 MCTF（运动补偿时域滤波）的 3×3 变换矩阵及画面裁剪参数：

```json
{
  "frameNum": 1,
  "matrixInfo": "{\"decayGain\":1.0,
    \"eis3x3Matrix\":[0.999,-0.043,-41.5,0.043,0.999,17.4,...],
    \"mctf3x3Matrix\":[1.010,-0.008,-125.3,0.009,1.008,161.3,...],
    \"srcDstWh\":[1920,1440,1728,1296]}"
}

```
| 标记 | 说明 | 与实况相关？ |
|------|------|:---:|
| `uuidextend_type_matrix` | 荣耀私有扩展段标识 | 否，视频后处理数据 |
| JSON 内 `eis3x3Matrix` | 逐帧电子防抖矩阵 | 否 |
| JSON 内 `mctf3x3Matrix` | 逐帧运动补偿矩阵 | 否 |
| `v2_fXX`（荣耀）/ `v6_fXX`（华为） / `PPP:QQQQ` / `LIVE_` | 标准华为尾部字段，含义与华为一致 | ✅ |
| `LIVE_NNNNNNN` | 实况照片判定标记，与华为完全一致 | ✅ |

> 以上 JSON 扩展为荣耀相机 ISP 管线输出的逐帧后处理数据，与实况照片协议无关。仅 `LIVE_` 是实况照片判定标记。

## 与实况照片的关系

`uuidextend_type_matrix`、`eis3x3Matrix`、`mctf3x3Matrix` 都属于视频后处理/防抖数据，不参与实况照片识别。真正决定实况照片身份的是核心 `LIVE_` 尾标及其对应的嵌入视频结构。

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
