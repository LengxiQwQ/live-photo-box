<div align="center">

# 华为 Moving Photo 实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析华为 Moving Photo 的 JPEG / HEIC 容器、LIVE_ 尾标、60 字节尾部、MP4 元数据与新旧封面帧机制。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

华为实况照片协议完全独立于 Google/OPPO/Apple 标准，**不使用 XMP 元数据**，通过私有二进制标记来标识和定位视频数据。两种容器格式——HEIC 和 JPEG——共用同一套尾部结构和 MP4 元数据。

**最小可用结构**（SDK 简化格式，已验证）：
```
[静态图片 JPEG/HEIC] + [完整 MP4 视频] + [60 字节尾部]
```

> **相关协议**：荣耀 Moving Photo 复用相同的核心尾部机制，其额外扩展见 [Honor Moving Photo](./Honor-Moving-Photo.md)。

## 文件结构

**HEIC**：静态图片（多分辨率 HEVC）+ 嵌入 MP4 + 尾部。定位 MP4：搜索第二个 `ftyp` box（major=`mp42`）。

**JPEG**：JPEG 图片 + 嵌入 MP4 + 尾部。定位 MP4：搜索 `ftyp` box（在 JPEG EOI 之后）。

## 实况照片识别：LIVE_ 尾标

`LIVE_` 是实况照片的**唯一判定标记**。相册通过扫描文件末尾的 `LIVE_` 字节序列来识别实况照片。其他标记（tmap、Track 3、com.openharmony.* 键等）均非必需。

### 60 字节尾部

```
v6_fXX            PPP:QQQQ            LIVE_NNNNNNN
```

| 偏移 | 字节 | 字段 | 含义 |
|------|:---:|------|------|
| [+0..+5] | 6 | `v6_fXX` | 封面帧序号（XX = 视频中帧号，0-based），供**旧版相册**读取 |
| [+6..+19] | 14 | 空格 | — |
| [+20..+27] | 8 | `PPP:QQQQ` | 只读历史记录（合成样本为 `帧号:总帧数`，真机如 `700:1300`，不建议据此换算秒） |
| [+28..+39] | 12 | 空格 | — |
| [+40..+51] | 12 | `LIVE_NNNNNNN` | **实况照片判定标记**，NNNNNNN = 嵌入 MP4 字节数 **+20** |
| [+52..+59] | 8 | 空格 | — |

> **LIVE_ 公式**：`嵌入 MP4 字节数 + 20`。经华为手机实测验证，+16 不可用（相册不识别），必须使用 +20。

## 封面帧机制

**华为相册有两个版本，读取不同的封面帧位置**：

| 相册版本 | 读取位置 | 格式 | 写入方式 |
|----------|----------|------|----------|
| **新版**（HarmonyOS 5+） | MP4 udta `com.openharmony.covertime` | 真机为 4 字节 **float32**（毫秒，如 `0x44A28B44 ≈ 1300.35`）；本软件合成写 UTF-8 字符串（如 `"1330.000000"`） | ffmpeg `-movflags use_metadata_tags` 注入 |
| **旧版** | 尾部 `v6_fXX` | 帧序号（整数，如 `29`） | 直接写入尾部字节 |

> **关键发现**：经实测，修改 `v6_fXX` 对最新版相册**无影响**——封面位置不变。只有写入 `com.openharmony.covertime` 到 MP4 udta 元数据后，封面位置才发生变化。`v6_fXX` 仅为旧版相册兼容保留。

**封面帧替换流程**（用户在相册中编辑封面时）：
1. 从视频中抽取选定帧 → 编码为 JPEG/HEIC → 替换文件前半段静态图
2. 视频完整保留（不裁切）
3. 更新 `com.openharmony.covertime`（新相册）和 `v6_fXX`（旧相册）
4. 更新 `LIVE_` = 新 MP4 字节数 + 20
5. `PPP:QQQQ` 保持原值不变（只读历史记录）

## MP4 视频与容器元数据

**ftyp**：`major=mp42`, `compat=iso2, mp42`

**最少 2 个轨道**即可正常播放：

| Track | 类型 | 编码 | 说明 |
|-------|------|------|------|
| Track 1 | 视频 | H.264 (avc1) | **必须 H.264**——HEVC 编码的视频华为相册无法播放 |
| Track 2 | 音频 | AAC | 44100Hz 或 48000Hz |

> Track 3（`com.openharmony.timed_metadata.movingphoto`）为原生相机自动附加，**非必需**。

**MP4 udta 元数据**：

| Key | 说明 | 必需？ |
|-----|------|:---:|
| `©too` = `"Openharmony6.1"` | 编码器标识 | 辅助 |
| `com.openharmony.covertime` | **封面帧毫秒时间戳**。真机 `ilst` 用 type `0x17` 存 float32；合成端可写 UTF-8 字符串 | ✅ **新版相册必需** |
| 其他 `com.openharmony.*` 键 | 拍摄元数据（encParam、starttime、videoId 等） | 否 |

## EXIF 辅助信息

| 字段 | 值 | 说明 |
|------|-----|------|
| Make | 保留来源值（方案 A） | 合成时不再改写为 `HUAWEI`，实况照片判定不依赖 Make；后备方案 B 详见 `LivePhotoMergeService.WriteHuaweiNativeAsync` 方法头注释 |
| MakerNote | `##**N4031` | 原生相机写入，非必需 |

## 提取

**提取静态图片**（封面帧）：
- HEIC：解析 ISOBMFF → `meta` → `iloc` → 提取全分辨率 HEVC → 转 JPEG/PNG
- JPEG：读取到第一个 `FF D9`（JPEG EOI）之前的数据即图片

**提取视频**：
```
mp4_start = 第二个 ftyp (major=mp42) 的位置 - 4   // HEIC
mp4_start = JPEG EOI 之后的 ftyp 位置 - 4          // JPEG
video = data[mp4_start : len(data) - 60]           // 减去尾部
```

## 合成

```
结构:  [静态图 JPEG/HEIC] + [完整 MP4] + [60B 尾部]

60B 尾部字段:
  [+0..+5]:   v6_fXX      (封面帧序号，旧版相册)
  [+20..+27]: PPP:QQQQ    (封面帧号:总帧数，只读记录)
  [+40..+51]: LIVE_NNNNN  (MP4字节数 + 20)

MP4 元数据:
  com.openharmony.covertime = "{StillImageTime_ms}.000000"  (新版相册封面位置)
  too = "Openharmony6.1"                                     (编码器标识)
```

## 更换封面

```
1. 从视频抽取目标帧 → 编码为 JPEG/HEIC
2. 替换文件前半段静态图片
3. 视频保留完整（不裁切）
4. 更新 com.openharmony.covertime = 新帧的时间戳（毫秒）
5. 更新 v6_fXX = 新帧序号
6. 更新 LIVE_ = 新 MP4 字节数 + 20
7. PPP:QQQQ 保持原值不变
```

## 关键参数速查

| 参数 | 值 |
|------|-----|
| 容器格式 | HEIC 或 JPEG |
| 尾部大小 | **60 字节** |
| LIVE_ 公式 | MP4 字节数 **+20** |
| 封面帧-新版 | MP4 udta `com.openharmony.covertime`（毫秒） |
| 封面帧-旧版 | 尾部 `v6_fXX`（帧序号） |
| PPP:QQQQ | 只读历史记录（真机格式不固定，不要据此换算秒） |
| 视频编码 | **H.264**（HEVC 不可用） |
| 视频 ftyp brand | `mp42` |
| 最小轨道 | Video + Audio（2 轨） |
| HEIC ftyp | 最后 4 字节替换为 `tmap`（辅助，非必需） |

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
