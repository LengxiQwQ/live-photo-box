<div align="center">

# OPPO O-Live Photo 实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析 OPPO / OnePlus O-Live Photo 的文件结构、Google V2 扩展、双封面时间戳与 EXIF 识别标记。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

OPPO / OnePlus 在 Google MotionPhoto V2 基础上扩展的私有协议。完全兼容 V2，同时增加 OPPO 独有字段。使用者：OPPO ColorOS、OnePlus OxygenOS。

> **相关协议**：O-Live Photo 的标准容器与 XMP 基础见 [Google MotionPhoto V2](./Google-MotionPhoto-V2.md)，本文重点记录 OPlus 扩展部分。

## 文件结构

OPPO 原厂文件比标准 V2 多了一个尾部区域：

```
┌──────────────────────┐
│   JPEG 图片           │
├──────────────────────┤
│   GainMap 增益图      │  ← HDR 相关，非实况照片协议内容
├──────────────────────┤
│   MP4 视频            │
├──────────────────────┤
│   OnePlus 尾部数据    │  ← 仅 OnePlus 机型，约 846 KB
└──────────────────────┘

```
人工合成的文件通常不含 OnePlus 尾部。

## XMP 元数据

在 V2 基础上新增 `OpCamera` 命名空间，增加 5 个属性：

```xml
<rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    xmlns:OpCamera="http://ns.oplus.com/photos/1.0/camera/"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="2762000"
    OpCamera:MotionPhotoOwner="oplus"
    OpCamera:OLivePhotoVersion="2"
    OpCamera:VideoLength="8275393"
    OpCamera:MotionPhotoPrimaryPresentationTimestampUs="1466388"
    OpCamera:MotionPhotoEnable="True">
  <Container:Directory>
    <rdf:Seq>
      <rdf:li rdf:parseType="Resource">
        <Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary"
                        Item:Length="0" Item:Padding="0"/>
      </rdf:li>
      <rdf:li rdf:parseType="Resource">
        <Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto"
                        Item:Length="9121768" Item:Padding="0"/>
      </rdf:li>
    </rdf:Seq>
  </Container:Directory>
</rdf:Description>

```
> Container:Directory 结构与 V2 一致——Primary 和 MotionPhoto 两个 Item。实际样本中 OPPO 文件可能包含第三个 GainMap Item（HDR 增益图），但与实况照片协议无关。

### OpCamera 字段

| 字段 | 说明 |
|------|------|
| `OpCamera:MotionPhotoOwner` | 所有者标识，固定为 `"oplus"`。OPPO 相册据此判断是否为自家拍摄 |
| `OpCamera:OLivePhotoVersion` | O-Live 协议版本，当前为 `"2"` |
| `OpCamera:VideoLength` | 纯视频字节数（不含 OnePlus 尾部）。原厂文件中 `Item:Length` = 视频+尾部，`VideoLength` = 纯视频。合成时两者相等 |
| `OpCamera:MotionPhotoPrimaryPresentationTimestampUs` | 主照片（原始拍摄帧）的微秒时间戳。原厂文件中与 `MotionPhotoPresentationTimestampUs` 相同；更换封面后，前者保持原值不变（指向原始拍摄帧），后者更新为新封面位置。两者分别记录"拍摄的那一帧"和"当前封面帧" |
| `OpCamera:MotionPhotoEnable` | 封面编辑标记。原厂文件无此字段；在 OPPO 相册中编辑封面后写入，值为 `True`。可用于判断封面是否被用户修改过 |

## 封面帧机制

OPPO 是唯一拥有**双时间戳**的协议，可区分"当前封面帧"和"原始拍摄帧"：

| 字段 | 含义 | 换封面后 |
|------|------|----------|
| `GCamera:MotionPhotoPresentationTimestampUs` | 当前封面帧在视频中的微秒位置 | **更新**为新封面位置 |
| `OpCamera:MotionPhotoPrimaryPresentationTimestampUs` | 原始拍摄帧（按下快门那一刻）的微秒位置 | **保持不变** |

原厂文件中两者相同。更换封面后，第一个字段变为新封面位置，第二个字段保留原始值。这是其他协议不具备的能力——可以同时知道"现在的封面在哪"和"当初拍摄的那一帧在哪"。

## EXIF UserComment

除 XMP 外，OPPO 相册还会检查 EXIF 中的 `UserComment` 字段：

```
UserComment = "oplus_10485792"
              │      │
              │      └── 最大视频字节数（10 MB）
              └── OPPO 前缀标识

```
不同机型该值可能不同：8388608 (8 MB)、10485792 (10 MB) 均有过出现。

若缺少此标记，OPPO 自带相册不会播放动态效果。Google Photos 和 Windows 11 不受影响——仅检查 XMP。

## 视频定位与兼容性

标准读取使用 `Container:Directory` 中 MotionPhoto Item 的 `Item:Length` 定位资源。`OpCamera:VideoLength` 记录纯视频字节数；OnePlus 原厂文件存在额外尾部时，两者可能不同。

Google Photos 和 Windows 主要依赖标准 MotionPhoto V2 XMP；OPPO / OnePlus 自带相册还会检查 OPlus 私有字段与 EXIF `UserComment`。

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
