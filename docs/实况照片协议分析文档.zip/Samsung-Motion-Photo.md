<div align="center">

# 三星 Motion Photo 实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析三星 Motion Photo 的 Google V2 XMP、Samsung Trailer、SEF 索引以及 HEIC 的 mpvd / sefd 容器结构。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

三星 Galaxy 设备的动态照片使用 **双轨制元数据**——同时写入 Google V2 XMP（兼容 Google Photos 等第三方 App）和私有二进制 **Samsung Trailer**（供三星相册使用）。三星相册**完全不读取 XMP**，仅依赖 Trailer 中的 `MotionPhoto_Data` 标签和 SEF 验证区来识别和播放动态照片。

使用者：三星 Galaxy S23 系列及以后、Galaxy Tab S9 系列等。内部格式自称为 **mpv2**（早期）或 **mpv3**（Galaxy S23 Ultra 起）。

> **相关协议**：三星文件中的第三方兼容 XMP 层参考 [Google MotionPhoto V2](./Google-MotionPhoto-V2.md)；三星相册自身识别依赖本文的 Samsung Trailer / SEF。

## JPEG 文件结构

与 Google V2 的关键区别：视频**嵌入在** Samsung Trailer 的 `MotionPhoto_Data` 标签 data 中，而非作为独立数据段追加在 JPEG EOI 之后：

```
┌──────────────────────────────────────┐
│   JPEG 图片                           │
│   (含 V2 XMP: GCamera:MotionPhoto=1   │
│    + Container:Directory)             │
├──────────────────────────────────────┤
│   Samsung Trailer 标签区               │
│   ├─ Image_UTC_Data       (0x0a01)   │
│   ├─ MCC_Data             (0x0aa1)   │
│   ├─ Camera_Scene_Info    (0x0d01)   │
│   ├─ Color_Display_P3     (0x0cc1)   │
│   ├─ Camera_Capture_Mode  (0x0c61)   │
│   ├─ MotionPhoto_Data     (0x0a30)   │  ← MP4 视频在此
│   └─ MotionPhoto_Version  (0x0a31)   │  ← "mpv2" 或 "mpv3"
├──────────────────────────────────────┤
│   SEF 验证区                          │
│   ├─ "SEFH" header                   │
│   ├─ 每个 Tag 的索引条目（offset+size）│
│   └─ "SEFT" footer                   │
└──────────────────────────────────────┘

```

> 整个 Trailer = 标签区 + SEF 区（含视频数据），追加在 JPEG EOI 之后、文件末尾。视频不是独立的顶层数据段——它是 `MotionPhoto_Data` 标签的 data payload。

## Samsung Trailer

### Tag 二进制编码

Samsung Trailer 中每个 Tag 的通用编码格式为：

```
偏移    长度    内容
+0      2       0x00 0x00（固定前导）
+2      2       Marker ID（小端序 uint16，如 0x0a30 → 字节 [0x30, 0x0a]）
+4      4       Name 字符串长度（小端序 uint32，含末尾 NUL）
+8      N       Name 字符串（UTF-8，如 "MotionPhoto_Data"）
+8+N    M       Data（M = 该 Tag 的数据长度，由 SEF 索引中的 size 字段给出）
```

例——`MotionPhoto_Data` 标签（JPEG 容器）的二进制编码：
```
00 00  30 0A  10 00 00 00  "MotionPhoto_Data"  <MP4 视频完整二进制>
```

### Tag 清单

| # | Marker (hex) | Name | 数据内容 | 说明 |
|---|:---:|---|---|---|
| 1 | `0x0a01` | `Image_UTC_Data` | Unix 时间戳（LE u32, 4 字节） | 拍摄时间，无时区信息 |
| 2 | `0x0aa1` | `MCC_Data` | 变长二进制 | 用途未完全文档化（可能与移动国家代码相关） |
| 3 | `0x0d01` | `Camera_Scene_Info` | 变长二进制 | 相机场景信息 |
| 4 | `0x0cc1` | `Color_Display_P3` | 变长二进制 | 广色域 Display P3 色彩标记 |
| 5 | `0x0c61` | `Camera_Capture_Mode_Info` | 变长二进制 | 拍摄模式信息 |
| 6 | `0x0a30` | `MotionPhoto_Data` | **JPEG**: 完整 MP4 视频字节<br>**HEIC**: `"mpv2"` + video_offset(BE u32) + video_size(BE u32) | ★ 核心标签——三星相册视此标签存在与否判定是否为动态照片 |
| 7 | `0x0a31` | `MotionPhoto_Version` | 版本字符串，如 `"mpv2"` 或 `"mpv3"` | 格式版本标识 |


> **ExifTool 映射**：ExifTool 将 marker `0x0a30` 抽象为两个逻辑字段——`EmbeddedVideoType`（值为 name 字符串 `"MotionPhoto_Data"`）和 `EmbeddedVideoFile`（值为 data 部分的视频字节）。但底层二进制仅有 marker + name + data 三段，不存在独立的 "type" 和 "file" 分离存储。

### SEF 验证区

SEF（Samsung Extended Format）位于所有 Tag 之后，是一个自描述索引区。三星相册通过 SEF 快速定位各 Tag 的偏移和长度——**缺少 SEF 区或 SEF 区数据不一致，三星相册将拒绝识别**。

```
偏移        长度        内容
+0          4           "SEFH"（魔数）
+4          4           Version（LE u32，固定为 107）
+8          4           Field Count（LE u32，= 实际写入的 Tag 数量，通常为 7）
+12         N×10        每个 Field 的索引条目：
                        [2B: 0x00 0x00] [2B: marker LE u16] [4B: offset_from_sef LE u32] [4B: size LE u32]
+12+N×10    4           SEF 总大小（LE u32，含此字段自身和 "SEFT"）
+16+N×10    4           "SEFT"（魔数）
```

各 Field 的 `offset_from_sef` 以 SEF 区起始位置（即 "SEFH" 的 +0 字节）为基准——Tag 中偏移值为 0 表示该 Tag 紧接在 SEFT 之后。

## Google MotionPhoto V2 兼容层

三星原厂文件会**同时写入**两套独立的元数据：

| 层 | 格式 | 用途 |
|---|------|------|
| **XMP** | Google MotionPhoto V2（`GCamera:MotionPhoto=1` + `Container:Directory`） | 兼容 Google Photos、Windows 资源管理器等第三方 App |
| **Trailer** | Samsung Private Trailer（7 Tags + SEFH/SEFT） | **三星相册唯一识别方式** |

关键事实：
- **三星相册完全不读取 XMP**，仅凭 Trailer 判定动态照片
- **Google Photos 不读取 Samsung Trailer**，仅凭 V2 XMP 判定
- 合成三星兼容的动态照片**必须同时写入两套元数据**，缺一不可

## Motion Photo v3（mpv3）

较新的三星设备（Galaxy S23 Ultra、Tab S9 等）在 `MotionPhoto_Version` 标签中写入 `"mpv3"` 而非 `"mpv2"`。两种版本的 Trailer 和 SEF 结构完全一致，仅版本字符串不同。MotionPhoto2 工具默认生成 `"mpv3"` 格式。

## HEIC：mpvd / sefd

当容器为 HEIC 时，三星不使用 JPEG Trailer 追加方式，而是通过两个私有 **ISOBMFF 顶层 box** 封装动态照片数据：

```
┌──────────────────────────────────────┐
│   HEIC 静态图片 (ftyp + meta + mdat)  │
│   (meta box 内含 V2 XMP)              │
├──────────────────────────────────────┤
│   mpvd box (Motion Photo Video Data) │
│   ├─ 4B: box size (BE u32)           │
│   ├─ 4B: "mpvd"                      │
│   ├─ MP4 视频原始字节                  │
│   └─ sefd box (嵌套在 mpvd 内部)      │
│       ├─ 4B: box size (BE u32)       │
│       ├─ 4B: "sefd"                  │
│       ├─ Tag 数据区（格式同 JPEG，     │
│       │   但 MotionPhoto_Data 不含视频）│
│       └─ SEFH/SEFT 验证区             │
└──────────────────────────────────────┘

```

**HEIC 与 JPEG 的关键区别**：

| 方面 | JPEG | HEIC |
|------|------|------|
| 视频位置 | 在 Trailer 的 `MotionPhoto_Data` data 中 | 在 mpvd box 中（sefd 之前） |
| `MotionPhoto_Data` 内容 | 完整 MP4 视频字节 | `"mpv2"` + video_offset(BE u32) + video_size(BE u32)（12 字节指针） |
| 视频偏移基准 | SEF 区起始（"SEFH" 位置） | mpvd box 起始 |
| 容器级标识 | 无 | mpvd + sefd box 名 |
| XMP Primary Padding | 0 | 8（= mpvd 头部 8 字节） |

> HEIC 下的 `MotionPhoto_Data` data 为 `"mpv2"`（4 字节）+ 视频在 mpvd box 内的字节偏移（BE u32）+ 视频字节长度（BE u32），共 12 字节。三星相册据此在 mpvd box 内定位视频数据。

## 封面帧机制

三星原厂文件的跨平台封面位置沿用 Google MotionPhoto V2 的 `GCamera:MotionPhotoPresentationTimestampUs`，单位为微秒。Samsung Trailer / SEF 主要负责三星相册对动态视频的识别和定位，没有额外定义一套独立的封面时间戳。

## 视频定位与提取

1. 使用 ExifTool 提取视频：`exiftool -b -EmbeddedVideoFile > video.mp4`
   （ExifTool 自动解析 Samsung Trailer，抽取 `0x0a30` 标签的 data 部分）
2. 使用 ExifTool 提取完整 Trailer：`exiftool -b -trailer > out.bin`
3. 手动替换视频需同步更新：
   - `MotionPhoto_Data` 的 data 部分（新视频字节）
   - SEF 索引中 `0x0a30` 条目的 size 字段
   - 所有后续 Tag 的 offset 字段
   - 简单截断并追加新 MP4 **会被三星相册拒绝**
4. HEIC 文件中的提取：搜索 `"mpvd"` box → 解析内部 sefd → 根据 `MotionPhoto_Data` 中的 offset/size 指针定位视频

## 合成与兼容性

- 合成三星兼容的动态照片需要**同时满足**：
  - **Samsung Trailer**（7 Tags + SEFH/SEFT）——供三星相册识别
  - **Google MotionPhoto V2 XMP**（`GCamera:MotionPhoto=1` + `Container:Directory`）——供 Google Photos 等第三方 App 识别
- Google Gallery 额外要求文件名以 `"MV"` 开头
- 参考实现：[PetrVys/MotionPhoto2](https://github.com/PetrVys/MotionPhoto2)（Python，完整处理 JPEG 和 HEIC 两种容器，默认生成 mpv3）
- Trailer 内部偏移量和 SEF 索引有严格的交叉引用关系，手动拼接极易出错，推荐程序化生成

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
