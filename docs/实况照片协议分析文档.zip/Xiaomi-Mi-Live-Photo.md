<div align="center">

# 小米 Mi-Live Photo 实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析小米 Mi-Live Photo 的 Google MotionPhoto V2 实现、MiCamera 元数据、私有 EXIF 与 JPEG 辅助段。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

小米直接使用 Google 标准协议（早期 MIUI → MicroVideo V1；当前 HyperOS → MotionPhoto V2），**无独立协议**。小米相册完全依赖 V2 识别和播放实况照片，不限制读取自家元数据——符合 V2 标准的其他品牌（如 OPPO）实况照片均可播放。

> **相关协议**：当前 HyperOS 的核心结构与字段定义见 [Google MotionPhoto V2](./Google-MotionPhoto-V2.md)；早期 MIUI 使用 [Google MicroVideo V1](./Google-MicroVideo-V1.md)。

## 文件结构

JPEG 主图片位于文件前部，MP4 视频追加在文件末尾。较新机型可能包含 GainMap 增益图：

```
┌──────────────────────┐
│   JPEG 图片           │
│   (含 EXIF + XMP)     │
├──────────────────────┤
│   GainMap 增益图      │  ← Ultra HDR，非实况照片协议内容
├──────────────────────┤
│   MP4 视频            │
└──────────────────────┘

```

## XMP 元数据

完全使用 Google MotionPhoto V2 标准，无私有扩展字段。`Container:Directory` 中除 Primary 和 MotionPhoto 外可能包含 GainMap Item（HDR 增益图，与实况无关）。

小米额外写入一个 `MiCamera` 命名空间（`http://ns.xiaomi.com/photos/1.0/camera/`），当前格式为 `MiCamera:XMPMeta`，内容为 XML 编码的 `video_madrid_image` 元数据。该字段 `offset="0" length="0"`，**不参与视频定位**——视频定位完全由 V2 的 `Item:Length` 决定。🔴 早期 HyperOS 版本是否使用 `MiCamera:VideoLength` 待确认。

```xml
<rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    xmlns:MiCamera="http://ns.xiaomi.com/photos/1.0/camera/"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="1533248"
    MiCamera:XMPMeta="&lt;video_madrid_image type=&quot;701&quot;
      offset=&quot;0&quot; length=&quot;0&quot;
      width=&quot;3072&quot; height=&quot;4096&quot;
      paddingx=&quot;86&quot; paddingy=&quot;86&quot;
      location_enabled=&quot;0&quot; time_enabled=&quot;0&quot; dark=&quot;0&quot; /&gt;">
  <Container:Directory>
    <rdf:Seq>
      <rdf:li>  <!-- Primary: image/jpeg -->
      <rdf:li>  <!-- GainMap: image/jpeg（HDR，与实况无关） -->
      <rdf:li>  <!-- MotionPhoto: video/mp4 -->
    </rdf:Seq>
  </Container:Directory>
</rdf:Description>

```

## 封面帧机制

当前 HyperOS 使用 Google MotionPhoto V2 的 `GCamera:MotionPhotoPresentationTimestampUs` 记录封面帧在视频中的微秒位置。视频定位由 `Container:Directory` 的 `Item:Length` 完成，`MiCamera:XMPMeta` 不参与封面或视频定位。

## EXIF 辅助信息

| Tag (Hex) | IFD | 内容 | 与实况相关？ |
|-----------|-----|------|:---:|
| `0x010f` Make | IFD0 | 固定为 `"Xiaomi"` | 否 |
| `0x0110` Model | IFD0 | 设备型号 | 否 |
| `0x9a00` XiaomiModel | IFD0 | 小米内部型号名 | 否 |
| `0x889e` | ExifIFD | JSON 设备信息（`buildDevice`、`livephotoInfo`、`waterLogo` 等），详见下方 | 否 |
| `0x8895` | ExifIFD | `0`（版本标记，🔴 "新=3"说法待验证） | 🔴 |
| `0x8889` | ExifIFD | `"HDR"` | 🔴 |
| `0x8897` | ExifIFD | `1` | 🔴 |
| `0x889a` | IFD0 + ExifIFD | `0` | 🔴 |
| `0x889d` | IFD0 + ExifIFD | `"Madrid"`（相机功能代号） | 🔴 |
| `0x889f` | ExifIFD | `0` | 🔴 |
| `0x88a2` | IFD0 | 浮点数组（传感器数据） | 🔴 |
| `0x88a3` | IFD0 | `{}` | 🔴 |

### 0x889e JSON 内容

```json
{
  "buildDevice": "popsicle",
  "customize": "",
  "livephotoInfo": "tailShakeI:97 head:14447250877 time:14449050877 tail:14450590877
                    filterId:66048 onlyPreDuration:false  offset:266752 tailOffset:934708 ",
  "version": 2,
  "waterLogo": "XIAOMI",
  "waterName": "17 Pro Max"
}

```
| 字段 | 说明 | 与实况相关？ |
|------|------|:---:|
| `buildDevice` | 设备代号 | 否 |
| `customize` | 自定义标记（旧版为 `cvLensName` + `filterName`） | 否 |
| `livephotoInfo` | 拍摄元数据（`head`/`time`/`tail` 为系统时钟值，`offset`/`tailOffset` 为字节偏移）。合成时可填 0 占位 | 否 |
| `version` | JSON 格式版本 | 否 |
| `waterLogo` / `waterName` | 水印标识 / 设备名 | 否 |

> 🔴 `livephotoInfo` 中 `tailShakeI`、`headShakeI`、`onlyPreDuration` 字段用途待确认，与实况照片协议无关。

## JPEG 私有段

| 段标记 | 大小 | 内容 | 与实况相关？ |
|--------|------|------|:---:|
| APP3 `ALGO_COMMON` | ~20-24 KB | ISP 算法处理数据 | 否 |
| APP3 `OISINFO` | ~0.2-8 KB | OIS 光学防抖数据 | 否 |
| APP4 `XIAOMI_CUSTOMIZE` | ~640-770 B | 私有 EXIF 标签值冗余存储（JSON） | 否 |
| APP5 `CLOUD_WATER` | ~450 B | 🔴 用途待确认 | 🔴 |
| APP5 `XMI Camera Data` | 2 段，~65KB + 变长 | zlib 压缩相机数据 | 否 |

> APP3/APP4/APP5 各段均为相机 ISP 管线数据，与实况照片协议无关。

## 合成与兼容性

合成小米可用的实况照片**使用 Google MotionPhoto V2 协议即可**。小米相册不限制读取自家元数据，符合 V2 标准的其他品牌实况照片均可播放。如需小米相册完整显示型号和水印，额外写入 `Make`、`Model`、`0x889e` 三个字段即可。

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
