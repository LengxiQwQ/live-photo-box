<div align="center">

# vivo Live Photo（≤X200 系列）实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析 vivo X200 及更早机型双文件 Live Photo 的私有配对 ID、JPEG / MP4 元数据与双封面时间位置。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

旧版 vivo Live Photo 使用独立 JPG + MP4 双文件，通过私有元数据关联。该格式与 X300 系列采用的单文件 V2 路线完全不同。

> **相关协议**：X300 系列起改用完全不同的单文件方案，见 [vivo Live Photo（X300 系列起）](./vivo-Live-Photo-X300-and-later.md)。

## 文件结构

一张 `.jpg` + 一个 `.mp4`，两者文件名前缀相同，存放在同一目录下。删除 `.mp4` → 失去动态效果。

## 配对机制与私有元数据

两个文件**各自**在尾部携带一份私有 JSON，vivo 相册通过 `com.android.camera.livephoto` 字段的值进行配对。JSON 中其余字段均为 vivo 相机私有数据（设备信息、拍摄参数等），与实况照片识别无关。

**JPEG 尾部** — 文件末尾，格式为 `vivo{JSON}cameralbum!`：

```
vivo{"com.android.camera.hdr":49426,
     "com.android.camera.joint.fullview.orientation":0,
     "com.android.camera.fisheye":-1,
     "com.android.camera.takenmodel":"device_model",
     "com.android.camera.camerafacing":"0",
     "com.android.camera.livephoto":"pairing_id",
     "version":2104,
     ...}
cameralbum!

```
**MP4 尾部** — ISOBMFF `uuid` box（user type = `vivoMediaExtInfo`），同样包含 `vivo{JSON}`：

```
vivo{"com.android.camera.takenmodel":"device_model",
     "com.android.camera.camerafacing":"0",
     "com.android.camera.imageTime":0,
     "com.android.camera.moduleid":"photo",
     "com.android.camera.livephoto":"pairing_id",
     "version":2104,
     "com.android.camera.faceInfo":{}}

```
| 字段 | 位置 | 说明 | 与实况相关？ |
|------|------|------|:---:|
| `com.android.camera.livephoto` | JPEG + MP4 | 实况照片配对 ID，两端一致 | ✅ |
| `cameralbum!` | 仅 JPEG | 尾部标记，标识此文件为实况照片 JPEG | ✅ |
| `uuidvivoMediaExtInfo` | 仅 MP4 | ISOBMFF box，标识此文件为实况照片 MP4 | ✅ |
| `com.android.camera.takenmodel` | JPEG + MP4 | 设备型号 | 否 |
| `com.android.camera.camerafacing` | JPEG + MP4 | 摄像头方向 | 否 |
| `com.android.camera.moduleid` | JPEG + MP4 | 拍摄模块（`"photo"`） | 否 |
| `version` | JPEG + MP4 | 格式版本号；写入编辑封面字段时使用 `2200` | 否 |
| `com.android.camera.imageTime` | 仅 MP4 | **原始拍摄封面的 0-based 视频帧序号**；换封面后保持不变 | ✅ |
| `com.vivo.gallery.livePhoto.newCoverTime` | 仅 MP4（编辑后） | **当前封面的毫秒时间戳**；第一帧为 `0`，末帧写视频时长边界 | ✅ |
| `com.vivo.gallery.livePhoto.bestTime` | 仅 MP4（编辑后） | 编辑状态字段；当前封面定位不读取该字段 | 否 |
| `com.android.camera.faceInfo` | 仅 MP4 | 人脸检测数据 | 否 |
| `com.android.camera.hdr` | 仅 JPEG | HDR 模式参数 | 否 |
| `com.android.camera.fisheye` | 仅 JPEG | 鱼眼镜头参数 | 否 |
| `com.android.camera.joint.fullview` | 仅 JPEG | 全屏取景标记 | 否 |
| `com.android.camera.joint.fullview.orientation` | 仅 JPEG | 取景方向 | 否 |
| `com.vivo.xdr.maxGain` | 仅 JPEG | XDR 增益值 | 否 |
| `com.android.camera.watermarkVersion` | 仅 JPEG | 水印版本 | 否 |
| `com.android.camera.project` | 仅 JPEG | 内部项目代号 | 否 |

> 以下字段属于可选的相机功能数据，并非实况照片识别或封面定位所必需：
> - `com.android.camera.document` — 文档扫描模式
> - `com.android.camera.joint.conshoot` — 连拍标记
> - `com.android.camera.joint.motioncapture` — 动态拍摄状态；实况照片功能不依赖它

## 封面帧机制

vivo 旧双文件采用“一个静态图像 + 两个时间位置”的设计：

1. `imageTime` 记录原始拍摄帧，单位是 **0-based 帧序号**，用户换封面后不变。
2. `newCoverTime` 记录当前编辑封面，单位是**毫秒**；字段缺失表示未编辑，当前封面回退到 `imageTime`。
3. 独立 JPG 始终是当前展示的高清封面本体。换封面时既要替换 JPG，也要更新 MP4 中的 `newCoverTime`。
4. 选择末帧时，vivo 相册写入视频总时长的毫秒边界，不是末帧自身的 PTS。
5. `imageTime` 只保留原始封面在视频中的位置；换封面后，协议中没有额外保存第二份原始高清 JPG。原始画面只能从 MP4 对应帧恢复，其清晰度受视频编码与分辨率限制。

封面状态由以下字段组合确定：

| 状态 | 独立 JPG | `imageTime` | `newCoverTime` | `bestTime` | `version` |
|------|------|------|------|------|------|
| 未编辑 / 新制作 / 协议转换 | 唯一的当前高清封面 | 当前封面的 0-based 帧号，同时作为初始基准位置 | 缺失 | 缺失 | `2104` |
| 已编辑 | 替换为新选择帧生成的高清封面 | 保持原始帧号不变 | 当前封面的毫秒位置 | `0`，不参与当前封面定位 | `2200` |

新制作或协议转换生成的是一份没有封面编辑历史的新文件：只把转换时的当前封面写入 `imageTime`，不继承源协议中的原始封面位置，也不写 `newCoverTime` 或 `bestTime`。因此读取端只显示一个当前封面节点。只有之后人为更换封面，才保留原有 `imageTime` 并新增 `newCoverTime`，形成原始封面和当前封面两个节点。

`newCoverTime` 的取值规则：

- 第一帧写 `0`。
- 中间帧写该帧在视频时间轴上的毫秒位置。
- 最后一帧写视频总时长向下取整后的整数毫秒边界。
- 字段不存在时，读取端必须用 `imageTime` 作为当前封面位置。

更换封面时必须同时执行以下操作，缺一不可：

1. 从 MP4 取得目标帧并生成新的独立 JPG，保留需要的 EXIF 信息。
2. JPEG 与 MP4 写入相同的 `com.android.camera.livephoto` 配对 ID。
3. MP4 保留原有 `imageTime`，并写入目标位置对应的 `newCoverTime`。
4. MP4 中只保留一份 `vivoMediaExtInfo` UUID box，避免旧字段与新字段同时存在。

## 与 [OPPO O-Live Photo](./OPPO-O-Live-Photo.md) 封面存储的区别

两者都分别记录原始封面位置和当前封面位置，但静态图像的保存方式不同：

| 协议 | 当前高清封面 | 原始高清封面 | 原始位置 | 当前位置 |
|------|------|------|------|------|
| vivo ≤X200 | 独立 JPG | 不单独保留；只能从 MP4 帧恢复 | MP4 `imageTime`，0-based 帧号 | MP4 `newCoverTime`，毫秒 |
| OPPO O-Live Photo | 容器的 Primary JPEG | 改封面后保存在 `Item:Semantic="Original"` 项中 | `MotionPhotoPrimaryPresentationTimestampUs`，微秒 | `MotionPhotoPresentationTimestampUs`，微秒 |

因此，OPPO 改封面后的单文件容器可以同时包含当前与原始两张高清 JPEG；vivo ≤X200 则只有当前封面这一张高清 JPG，同时在 MP4 中保留原始帧位置和当前封面位置。

## 合成与兼容性

旧格式跨品牌兼容性极差，已被 X300 系列单文件 V2 取代，不建议基于此格式开发。

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
