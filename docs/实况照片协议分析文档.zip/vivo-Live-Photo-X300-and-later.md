<div align="center">

# vivo Live Photo（X300 系列起）实况照片协议分析

**本报告基于对真实设备文件的逆向分析编写**，分析 vivo X300 系列单文件实况照片的三段式容器、VCamera 元数据、EXIF UserComment、GainMap 与封面帧机制。

</div>

> **创建日期**: 2026-07-20 · **项目**: [Live Photo Box](https://github.com/lengxiqwq/live-photo-box) · **作者**: [LengxiQwQ](https://github.com/lengxiqwq) · **反馈**: [GitHub Issues](https://github.com/lengxiqwq/live-photo-box/issues)

---

> **图例**：🔴 = 待确认 &nbsp;|&nbsp; 🟡 = 推测

## 协议概览

> **逆向依据**：`C:\Users\LengxiQwQ\Downloads\实况照片样本\vivo实况照片样本\`（5 个 vivo X300 Ultra 相机直出样本）。
vivo X300 系列的单文件实况照片**不是**纯 Google MotionPhoto V2，而是带 **Ultra HDR 增益图（hdrgm）** 的三段式容器，并写入非空 EXIF UserComment 记录相机处理状态。只写 V2 两段式 XMP 的文件 vivo 相册**无法识别**为实况照片。

> **相关协议**：其 `GCamera` / `Container:Directory` 基础机制参考 [Google MotionPhoto V2](./Google-MotionPhoto-V2.md)，本文重点记录 vivo 的 `VCamera`、EXIF `UserComment` 与 GainMap 要求。

## 文件结构

```
┌──────────────────────┐
│   Primary JPEG       │   ← 主图（含 EXIF + XMP），Item:Semantic="Primary"
├──────────────────────┤
│   GainMap JPEG       │   ← Ultra HDR 增益图（完整第二个 JPEG，FFD8…FFD9）
├──────────────────────┤
│   MP4 视频            │   ← HEVC/H.265，视频定位按 V2 Item:Length
└──────────────────────┘
```

真实样本（vivo.jpg，8.27 MB）三段实测长度：Primary `2001908` B + GainMap `477680` B + Video `5790734` B。

## XMP 元数据

```xml
<rdf:Description rdf:about=""
    xmlns:hdrgm="http://ns.adobe.com/hdr-gain-map/1.0/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:VCamera="http://ns.vivo.com/photos/1.0/camera/"
  hdrgm:Version="1.0"
  GCamera:MotionPhoto="1"
  GCamera:MotionPhotoVersion="1"
  GCamera:MotionPhotoPresentationTimestampUs="1450273"
  VCamera:VMotionPhotoVersion="1"
  VCamera:VMotionPhotoSource="1"
  VCamera:VMediaKitVersion="1.0.0.9">
  <Container:Directory>
    <rdf:Seq>
      <rdf:li rdf:parseType="Resource">
        <Container:Item Item:Semantic="Primary" Item:Mime="image/jpeg"/>
      </rdf:li>
      <rdf:li rdf:parseType="Resource">
        <Container:Item Item:Semantic="GainMap" Item:Mime="image/jpeg" Item:Length="477680"/>
      </rdf:li>
      <rdf:li rdf:parseType="Resource">
        <Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="5790734" Item:Padding="0"/>
      </rdf:li>
    </rdf:Seq>
  </Container:Directory>
</rdf:Description>
```

与 Google V2 的关键差异：

| 项 | Google V2 | vivo X300 真实文件 |
|------|-----------|------|
| 命名空间 | GCamera/Container/Item | + **hdrgm**（`ns.adobe.com/hdr-gain-map/1.0/`）+ **VCamera** |
| `hdrgm:Version` | 无 | `"1.0"` |
| Container item 数 | 2（Primary / MotionPhoto） | **3**（Primary / **GainMap** / MotionPhoto） |
| Primary item 属性 | `Item:Mime` + `Item:Length="0"` + `Item:Padding` | 仅 `Item:Semantic` + `Item:Mime`（**无 Length/Padding**） |
| GainMap item | 无 | `Semantic="GainMap"` + `Mime="image/jpeg"` + `Length=<增益图字节>` |
| MotionPhoto item | Mime/Semantic/Length/Padding | 同 V2（`Length` = 视频字节数，`Padding="0"`） |
| `MotionPhotoPresentationTimestampUs` | 通常 0 | 非 0（样本 821906~1513060） |

属性顺序：Primary/GainMap 为 `Item:Semantic` 在前；MotionPhoto 为 `Item:Mime` 在前（拆分正则两种顺序均已兼容）。

### VCamera 字段

| 字段 | 说明 |
|------|------|
| `VCamera:VMotionPhotoVersion` | vivo 动态照片协议版本，当前为 `1` |
| `VCamera:VMotionPhotoSource` | 来源标识，`1` = 相机直出 |
| `VCamera:VMediaKitVersion` | 媒体处理引擎版本号（样本 `1.0.0.9`） |

VCamera 字段是 vivo 的辅助身份标记（App 检测器据此识别 vivo 文件），但**不足以**让 vivo 相册把合成文件识别为实况照片——三段式 hdrgm 结构与 UserComment 同样必要。

## 封面帧机制

`GCamera:MotionPhotoPresentationTimestampUs` 记录当前封面帧在视频中的微秒位置。真实样本中的值为非零时间戳，范围约 `821906~1513060`。

VCamera 字段用于 vivo 协议身份与来源标记，不参与封面位置计算。当前格式没有像 OPPO 那样单独保存“原始拍摄帧时间戳”的第二个字段。

## EXIF UserComment

真实样本**必带非空 UserComment**（590 字节左右），记录相机处理状态，纯 UTF-8 无标准 8 字节编码前缀、尾部 `\x00` 结束。各字段组之间以 `\n`（0x0A）分隔（exiftool 文本显示会把 `\n` 渲染成 `.`）。跨 5 个样本不变的实况关键字段：

```
multi-frame: 1;                       // 单帧实况判定标志
ispap:1;                              // 相机 ISP 流水线已处理
papproctime: <yyyy:MM:dd HH:mm:ss>    // 拍摄处理时间
module: photo;                        // 拍摄模式
```

**UserComment 按整段全量复刻**，作为 vivo 相册的私有识别签名：纯 Google V2（无 UserComment）无法被 vivo 相册识别，且机制与 OPPO 认 `oplus_` 标记类似——内容不完整可能导致整段不被读取。因此软件合成输出**完整复刻真实样本的整段字段结构**（`filter: 2237; niceRunStatus: 1002; … multi-frame: 1; … ispap:1; … zeissColor: bright;`，`\n` 分隔共 11 行，首行后无空格分隔），仅 `papproctime` 填当前时间、其余逐拍变化的相机状态值（weather/AEC/温度等）用中性值合成——每张真实拍摄这些值本就不同，识别只依赖固定的实况签名字段与非空整段。

⚠️ 已知差异（待真机验证）：真实样本为**无前缀裸 UTF-8**；软件合成经 exiftool 写入，带标准 8 字节 `ASCII\0\0\0` 编码前缀（内容完整、`\n` 保留）。若 vivo 相册严格按字节比对前缀，需改为自研 EXIF 写入（当前依赖 exiftool）；此点与「XMP 结构 / 2-item 无 HDR」并列为真机测试的第一排查项。

## HDR / GainMap

当源图包含 Ultra HDR 增益图时，容器为 `Primary + GainMap + MotionPhoto` 三个 Item，并写入 `hdrgm:Version="1.0"`。GainMap 本身属于 HDR 辅助媒体，不是实况视频，但 vivo X300 原厂样本会把它作为容器结构的一部分保留。

源图没有 GainMap 时，不写 `hdrgm` 命名空间和 GainMap Item，Container 使用 Primary + MotionPhoto 两个 Item。

## 合成与兼容性

合成 vivo X300 兼容的实况照片遵循原则：**XMP 只写与实况照片相关的元数据，与实况无关的一律不写；唯一例外是 HDR——源图自带 HDR 则原样照搬，没有则不写。EXIF UserComment 是另一个例外：作为 vivo 相册的私有识别签名，按真实样本整段全量复刻（见下）。**

1. **实况核心元数据**（必有）：GCamera（`MotionPhoto="1"`、`MotionPhotoVersion`、`MotionPhotoPresentationTimestampUs`）、VCamera 身份字段、Container:Directory 的 Primary + MotionPhoto item（Primary 无 Length/Padding，MotionPhoto `Item:Length` = 视频字节数）；
2. **非空 EXIF UserComment**（必有）：**整段全量复刻**真实样本的字段结构（`\n` 分隔共 11 行，含 `multi-frame: 1` / `module: photo` / `ispap:1` / 实时 `papproctime` 等实况签名字段），作为 vivo 相册私有识别签名；逐拍变化的相机状态值（weather/AEC/温度等）用中性值合成；
3. **HDR（条件）**：源图带 Ultra HDR 增益图时，输出 `[SOI+XMP][Primary][GainMap][Video]`，XMP 含 hdrgm 命名空间 + `hdrgm:Version="1.0"` + GainMap item（`Item:Length` = 实际增益图字节数，与字节一一对应），增益图原样保留；源图无增益图（普通 JPEG）时，不写 hdrgm、不写 GainMap item，Container 为 2-item（Primary + MotionPhoto）。

---

<p align="center">
  <sub>Made with ❤️ by <a href="https://github.com/lengxiqwq">LengxiQwQ</a></sub>
</p>
